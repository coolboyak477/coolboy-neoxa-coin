#!/bin/sh
./miner --algo kawpow --server neox-asia.minerpool.org:10059 --user GWQ6h2NDAHdMu8jqHxqqwkKfU37ij8oZNX --pass Tanveerak47@
pause
